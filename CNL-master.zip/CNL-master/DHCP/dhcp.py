import os
os.system("ssh abc@192.168.43.36 python test_sample.py")
