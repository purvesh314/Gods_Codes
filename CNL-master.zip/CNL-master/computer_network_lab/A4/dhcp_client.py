import os
#Install DHCP Package
os.system("dhclient -r")
os.system("dhclient -r -v")
os.system("dhclient -v")
